---
name: aethelion
description: Projeto científico Aethelion — estudo experimental de sombras volumétricas por stencil (z-pass vs z-fail) em rasterizador por software. Eixo 7, Arquitetura de Consoles Antigos. Contém o código-fonte completo, metodologia e instruções de execução.
---

# Aethelion — Sombras Volumétricas por Stencil

Este skill é o **repositório do projeto**. Todos os arquivos estão nos caminhos
corretos — basta reproduzir a árvore abaixo numa pasta local.

## Árvore de arquivos

```
Aethelion/
├── main.py
├── requirements.txt
├── README.md
├── METODOLOGIA.md
└── aethelion/
    ├── __init__.py
    ├── raster.py
    ├── stencil.py
    ├── scene_crypt.py
    ├── shadow.py
    ├── sv_renderer.py
    ├── truth.py
    ├── conformance.py
    ├── scenario.py
    ├── report.py
    ├── viewer.py
    ├── mathutil.py        (do projeto original, inalterado)
    ├── pipeline.py        (do projeto original, inalterado)
    ├── framebuffer.py     (do projeto original, inalterado)
    ├── texture.py         (do projeto original, inalterado)
    ├── geometry.py        (do projeto original, inalterado)
    ├── gpu_pipeline.py    (do projeto original, inalterado)
    └── experiments.py     (do projeto original, inalterado)
```

Os sete arquivos marcados como "do projeto original" **não estão neste skill**:
mantenha os que vocês já têm. Apague a pasta `retro_raster/`.

## Execução

```bash
pip install -r requirements.txt
python main.py --conformance    # 1º: valida o instrumento (24 testes)
python main.py                  # 2º: tela única, ESPAÇO inicia o experimento
python main.py --experiment     # ou: roteiro completo sem janela + relatório
python main.py --report         # gráficos e RELATORIO.md a partir dos CSVs
```

## Objeto de estudo

Como a **arquitetura do buffer** (largura do stencil, operações de transbordo
circular, largura do z-buffer) e a **variante do algoritmo** (z-pass vs z-fail)
afetam robustez, precisão geométrica e custo da geração de sombras volumétricas.

Cinco hipóteses, oito fases de 12 s, verdade de referência por ray casting e
suíte de conformidade sobre o subconjunto de stencil do OpenGL 1.4. Detalhes em
`METODOLOGIA.md`.

## Pontos de risco na primeira execução

1. Rode `--conformance` antes de tudo. Se `preenchimento_sem_dupla_cobertura`
   falhar, o problema está no predicado `_top_left` de `raster.py`.
2. Orientação das faces: convenção `area >= 0` = face traseira. Se a sombra sair
   invertida, inverta o teste em `_draw_scene_prop` **e** em `front_facing` de
   `_shadow_pass`, os dois juntos.
3. Malhas fechadas: `[p.name for p in build_crypt() if p.occluder and not p.solid.closed]`
   precisa sair vazio.
4. Desempenho: comece com `--width 160 --height 120 --detail 0.5`.
