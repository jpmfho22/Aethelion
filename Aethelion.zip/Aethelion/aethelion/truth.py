"""Verdade de referência por ray casting e métricas de concordância.

A referência NÃO usa stencil nem volumes: para cada pixel visível, lança-se um
raio do ponto de superfície até a fonte de luz e testa-se oclusão contra a
geometria da cena. É um método independente do algoritmo em avaliação, o que é
a condição para que precisão, revocação e F1 tenham significado.

Custo elevado: executa apenas nos quadros de medição e, se necessário, em
resolução reduzida. Isso está declarado na metodologia.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict

import numpy as np

F = np.float32


def occluder_soup(props) -> np.ndarray:
    """Concatena os triângulos oclusores em espaço de mundo."""
    out = []
    for p in props:
        if not p.occluder:
            continue
        pos = p.solid.positions
        ph = np.concatenate([pos, np.ones((pos.shape[0], 1), dtype=F)], axis=1)
        pw = (p.model @ ph.T).T[:, :3].astype(F)
        idx = p.solid.indices
        out.append(np.stack([pw[idx[:, 0]], pw[idx[:, 1]], pw[idx[:, 2]]], axis=1))
    if not out:
        return np.zeros((0, 3, 3), dtype=F)
    return np.concatenate(out, axis=0).astype(F)


def shadow_mask_raycast(points: np.ndarray, light: np.ndarray,
                        tris: np.ndarray, bias: float = 2.5e-3,
                        chunk: int = 2048) -> np.ndarray:
    """True onde o ponto está em sombra. points: (N,3) em espaço de mundo."""
    n = points.shape[0]
    out = np.zeros(n, dtype=bool)
    if n == 0 or tris.shape[0] == 0:
        return out

    v0, v1, v2 = tris[:, 0], tris[:, 1], tris[:, 2]
    e1, e2 = v1 - v0, v2 - v0

    for start in range(0, n, chunk):
        pts = points[start:start + chunk]
        d = light[None, :] - pts
        dist = np.linalg.norm(d, axis=1, keepdims=True)
        dirs = d / np.maximum(dist, 1e-9)
        origin = pts + dirs * bias
        limit = (dist[:, 0] - 2.0 * bias)

        # (P, T) por broadcasting
        pv = np.cross(dirs[:, None, :], e2[None, :, :])
        det = np.einsum("ptj,tj->pt", pv, e1)
        ok = np.abs(det) > 1e-9
        inv = np.zeros_like(det)
        np.divide(1.0, det, out=inv, where=ok)

        tvec = origin[:, None, :] - v0[None, :, :]
        u = np.einsum("ptj,ptj->pt", tvec, pv) * inv
        ok &= (u >= 0.0) & (u <= 1.0)

        qv = np.cross(tvec, e1[None, :, :])
        v = np.einsum("pj,ptj->pt", dirs, qv) * inv
        ok &= (v >= 0.0) & ((u + v) <= 1.0)

        t = np.einsum("tj,ptj->pt", e2, qv) * inv
        ok &= (t > 0.0) & (t < limit[:, None])

        out[start:start + chunk] = ok.any(axis=1)
    return out


@dataclass
class Agreement:
    """Concordância entre a máscara prevista e a de referência."""
    tp: int = 0
    fp: int = 0
    fn: int = 0
    tn: int = 0

    @property
    def precision(self) -> float:
        d = self.tp + self.fp
        return float(self.tp / d) if d else 1.0

    @property
    def recall(self) -> float:
        d = self.tp + self.fn
        return float(self.tp / d) if d else 1.0

    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        return float(2 * p * r / (p + r)) if (p + r) > 0 else 0.0

    @property
    def error_rate(self) -> float:
        tot = self.tp + self.fp + self.fn + self.tn
        return float((self.fp + self.fn) / tot) if tot else 0.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(precision=self.precision, recall=self.recall,
                 f1=self.f1, error_rate=self.error_rate)
        return d


def compare_masks(pred: np.ndarray, truth: np.ndarray) -> Agreement:
    p = np.asarray(pred, dtype=bool)
    g = np.asarray(truth, dtype=bool)
    return Agreement(tp=int(np.count_nonzero(p & g)),
                     fp=int(np.count_nonzero(p & ~g)),
                     fn=int(np.count_nonzero(~p & g)),
                     tn=int(np.count_nonzero(~p & ~g)))


def diff_image(pred: np.ndarray, truth: np.ndarray, visible: np.ndarray) -> np.ndarray:
    """Imagem de falsa cor: verde=acerto, vermelho=falso positivo, azul=falso negativo."""
    h, w = pred.shape
    img = np.zeros((h, w, 3), dtype=np.uint8)
    img[...] = 24
    agree = visible & (pred == truth)
    fp = visible & pred & ~truth
    fn = visible & ~pred & truth
    img[agree] = (40, 150, 60)
    img[fp] = (210, 50, 40)
    img[fn] = (50, 90, 220)
    return img
